/*
  Cover letter: the draft text, the letter "model" the preview and the PDF both draw from, and saving.
  No React and no browser-only code except localStorage (always inside try/catch), so it can be tested on its own.

  Flow
    resumeData + what the person typed (details)  ->  buildDraft()        a starting text, from the resume only
    resumeData + details + body                   ->  buildLetterModel()  everything the letter shows
    model                                         ->  utils/coverLetterPdf.js (layout, preview, PDF)

  The draft only repeats what is in the resume (names, job titles, employers, skills, qualification). It never
  invents achievements or claims. Everything in it can be edited by the person.
*/

export const TONES = [
  { id: 'formal', label: 'Formal' },
  { id: 'confident', label: 'Confident' },
  { id: 'warm', label: 'Warm' },
];
const TONE_IDS = TONES.map((t) => t.id);

const MAX_FIELD = 200;
const MAX_BODY = 8000;
const MAX_BULLETS = 3;
const MAX_SKILLS = 5;

/* ------------------------------------------------------------------ small text helpers */

const clean = (value) => String(value ?? '').replace(/\s+/g, ' ').trim();

// The builder keeps **bold**, *italic* and "- " bullets as plain text. A letter shows none of that markup.
export const stripMarkup = (text) =>
  clean(String(text ?? '').replace(/\*\*(.+?)\*\*/g, '$1').replace(/\*(.+?)\*/g, '$1'));

// One resume achievements box -> its lines, without bullet marks or markup.
export const achievementLines = (text) =>
  String(text ?? '')
    .split(/\r?\n/)
    .map((line) => stripMarkup(line.trim().replace(/^([-\u2022]\s+|\*\s+)/, '')))
    .filter(Boolean);

// "A, B and C"
export const joinList = (items) => {
  const list = items.filter(Boolean);
  if (list.length <= 1) return list.join('');
  return `${list.slice(0, -1).join(', ')} and ${list[list.length - 1]}`;
};

// Letters whose NAME starts with a vowel sound, for "an MBA", "an HR officer", "an MSc".
const VOWEL_SOUND_LETTERS = new Set('AEFHILMNORSX');

// "a" or "an" for the word that follows.
export const article = (word) => {
  const w = clean(word);
  if (!w) return 'a';
  if (/^[A-Z]{2}/.test(w)) return VOWEL_SOUND_LETTERS.has(w[0]) ? 'an' : 'a';
  if (/^(hono|hour|heir)/i.test(w)) return 'an';
  return /^[aeiou]/i.test(w) ? 'an' : 'a';
};

/* ------------------------------------------------------------------ what the resume says */

const namedJobs = (resumeData) =>
  (Array.isArray(resumeData?.experiences) ? resumeData.experiences : []).filter((j) => clean(j.title) || clean(j.employer));

const namedEducation = (resumeData) =>
  (Array.isArray(resumeData?.education) ? resumeData.education : []).filter((e) => clean(e.institution) || clean(e.degree));

const namedSkills = (resumeData) =>
  (Array.isArray(resumeData?.skills) ? resumeData.skills : []).map((s) => clean(s?.text)).filter(Boolean);

export const fullNameOf = (personal) => clean(`${personal?.firstName || ''} ${personal?.lastName || ''}`);

// Whole years between the earliest start year and the latest end year (or this year for a current job).
// 0 when the resume has no usable years.
export const yearsOfExperience = (jobs, now = new Date().getFullYear()) => {
  let start = Infinity;
  let end = -Infinity;
  jobs.forEach((job) => {
    const s = parseInt(job.startYear, 10);
    if (!Number.isFinite(s)) return;
    const e = job.current ? now : parseInt(job.endYear, 10);
    start = Math.min(start, s);
    end = Math.max(end, Number.isFinite(e) ? e : s);
  });
  if (!Number.isFinite(start) || end <= start) return 0;
  return Math.min(end - start, 60);
};

// Job titles that stand alone ("as Head of Sales"), so no "a" before them.
const NO_ARTICLE_TITLE = /^(head|chief|director|vice|president|ceo|cto|cfo|coo)\b/i;

// "as a Front-End Developer at Acme", "as a Developer", or "at Acme" when the job has no title.
const asRole = (job) => {
  const title = clean(job.title);
  const employer = clean(job.employer);
  const role = title ? `as ${NO_ARTICLE_TITLE.test(title) ? '' : `${article(title)} `}${title}` : '';
  if (role && employer) return `${role} at ${employer}`;
  return role || `at ${employer}`;
};

/* ------------------------------------------------------------------ the draft */

const TONE_TEXT = {
  formal: {
    open: (target) => `I am writing to apply for ${target}.`,
    bullets: 'Key responsibilities and achievements in this role include:',
    skills: 'My core skills include',
    close: (who) =>
      `I would welcome the opportunity to discuss how my experience can contribute to ${who}. Thank you for your time and consideration.`,
  },
  confident: {
    open: (target) => `I am excited to apply for ${target}, and I believe my background is a strong match.`,
    bullets: 'Some of my key achievements in this role:',
    skills: 'My key strengths are',
    close: (who) =>
      `I would value the chance to discuss how I can contribute to ${who}. Thank you for considering my application.`,
  },
  warm: {
    open: (target) => `I would love to be considered for ${target}, and I am grateful for the chance to introduce myself.`,
    bullets: 'A few things I am proud of from this role:',
    skills: 'I enjoy working with',
    close: (who) =>
      `I would be delighted to talk about how I can help ${who}. Thank you so much for your time, and I look forward to hearing from you.`,
  },
};

// The position/company the letter is about, in a sentence-ready phrase.
const targetPhrase = (role, company) => {
  if (role && company) return `the ${role} position at ${company}`;
  if (role) return `the ${role} position at your organisation`;
  if (company) return `a role at ${company}`;
  return 'a role at your organisation';
};

/**
 * A starting text for the letter, built only from the resume and the details typed in the form.
 * Paragraphs are separated by a blank line; a line starting with "- " is a bullet.
 */
export function buildDraft(resumeData, details = {}) {
  const personal = resumeData?.personal || {};
  const jobs = namedJobs(resumeData);
  const education = namedEducation(resumeData);
  const skills = namedSkills(resumeData).slice(0, MAX_SKILLS);
  const tone = TONE_TEXT[TONE_IDS.includes(details.tone) ? details.tone : 'formal'];

  const role = clean(details.jobTitle);
  const company = clean(details.company);
  const profession = clean(personal.profession);

  const paragraphs = [];

  // 1. Who is writing, and for what.
  const years = yearsOfExperience(jobs);
  const intro = [tone.open(targetPhrase(role, company))];
  if (profession && years > 0) {
    intro.push(`I am ${article(profession)} ${profession} with ${years} ${years === 1 ? 'year' : 'years'} of professional experience.`);
  } else if (profession) {
    intro.push(`I am ${article(profession)} ${profession}.`);
  } else if (years > 0) {
    intro.push(`I bring ${years} ${years === 1 ? 'year' : 'years'} of professional experience.`);
  }
  paragraphs.push(intro.join(' '));

  // 2. The most recent job, its first few achievements, and the one before it.
  if (jobs.length > 0) {
    const latest = jobs[0];
    const bullets = achievementLines(latest.achievements).slice(0, MAX_BULLETS);
    let block = latest.current
      ? `I currently work ${asRole(latest)}.`
      : `Most recently, I worked ${asRole(latest)}.`;
    if (bullets.length > 0) block = `${block} ${tone.bullets}\n${bullets.map((b) => `- ${b}`).join('\n')}`;
    if (jobs[1]) block = `${block}\n\nBefore that, I worked ${asRole(jobs[1])}.`;
    paragraphs.push(block);
  }

  // 3. Skills and qualification.
  const about = [];
  if (skills.length > 0) about.push(`${tone.skills} ${joinList(skills)}.`);
  const qualification = education[0];
  if (qualification) {
    const degree = clean(qualification.degree);
    const field = clean(qualification.field);
    const institution = clean(qualification.institution);
    const degreeText = degree && field && !degree.toLowerCase().includes(field.toLowerCase()) ? `${degree} in ${field}` : degree;
    if (degreeText && institution) about.push(`I hold ${article(degreeText)} ${degreeText} from ${institution}.`);
    else if (degreeText) about.push(`I hold ${article(degreeText)} ${degreeText}.`);
    else if (institution && field) about.push(`I studied ${field} at ${institution}.`);
    else if (institution) about.push(`I studied at ${institution}.`);
  }
  if (about.length > 0) paragraphs.push(about.join(' '));

  // 4. Closing.
  paragraphs.push(tone.close(company || 'your team'));

  return paragraphs.join('\n\n');
}

/* ------------------------------------------------------------------ the body text -> blocks */

/**
 * The letter text -> [{ type: 'p', text } | { type: 'bullets', items: [text] }].
 * A blank line ends a paragraph. A line starting with "- " (or a bullet dot) is a bullet.
 * Single line breaks inside a paragraph are joined with a space.
 */
export function parseBody(body) {
  const blocks = [];
  let paragraph = [];
  let bullets = [];

  const flushParagraph = () => {
    if (paragraph.length > 0) blocks.push({ type: 'p', text: paragraph.join(' ') });
    paragraph = [];
  };
  const flushBullets = () => {
    if (bullets.length > 0) blocks.push({ type: 'bullets', items: bullets });
    bullets = [];
  };

  String(body ?? '')
    .split(/\r?\n/)
    .forEach((raw) => {
      const line = raw.trim();
      if (!line) {
        flushParagraph();
        flushBullets();
        return;
      }
      const bullet = line.match(/^[-\u2022]\s+(.*)$/);
      if (bullet) {
        flushParagraph();
        if (clean(bullet[1])) bullets.push(clean(bullet[1]));
        return;
      }
      flushBullets();
      paragraph.push(clean(line));
    });
  flushParagraph();
  flushBullets();
  return blocks;
}

/* ------------------------------------------------------------------ the letter model */

const todayISO = () => {
  const d = new Date();
  const pad = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
};

// '2026-11-07' -> '7 November 2026' (built from the parts, so the time zone can never move the day)
export const formatLetterDate = (iso) => {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(iso || ''));
  if (!match) return '';
  const date = new Date(Number(match[1]), Number(match[2]) - 1, Number(match[3]));
  if (Number.isNaN(date.getTime()) || date.getMonth() !== Number(match[2]) - 1) return '';
  return date.toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' });
};

// What the person typed as the manager's name, ready for "Dear ...": "Dear Ms Dlamini," -> "Ms Dlamini"
const managerName = (value) => clean(value).replace(/^dear\s+/i, '').replace(/[,;:]+$/, '').trim();

/**
 * Everything the letter shows, as plain strings and blocks. The preview and the PDF both draw from this, so
 * they can never disagree.
 *   { name, profession, contacts[], dateText, recipient[], salutation, blocks[], closing, signName }
 */
export function buildLetterModel(resumeData, letter, body) {
  const personal = resumeData?.personal || {};
  const name = fullNameOf(personal);
  const manager = managerName(letter?.hiringManager);

  const location = [clean(personal.city), clean(personal.province)].filter(Boolean).join(', ');
  const websites = (Array.isArray(personal.websites) ? personal.websites : [])
    .map((w) => clean(w?.url).replace(/^https?:\/\//i, '').replace(/\/$/, ''))
    .filter(Boolean);
  const contacts = [clean(personal.email), clean(personal.phone), location, ...websites].filter(Boolean);

  return {
    name,
    profession: clean(personal.profession),
    contacts,
    dateText: formatLetterDate(letter?.dateOverride || todayISO()),
    recipient: [manager, clean(letter?.company), clean(letter?.companyAddress)].filter(Boolean),
    salutation: manager ? `Dear ${manager},` : 'Dear Hiring Manager,',
    blocks: parseBody(body),
    closing: 'Yours sincerely,',
    signName: name,
  };
}

/* ------------------------------------------------------------------ saving */

const STORAGE_PREFIX = 'remopdf:coverLetter:';

export const defaultLetter = () => ({
  jobTitle: '',
  company: '',
  companyAddress: '',
  hiringManager: '',
  dateOverride: '', // '' = today
  tone: 'formal',
  body: '',
  bodyEdited: false, // false: the text follows the draft; true: the person has written their own
});

const text = (value, max) => String(value ?? '').slice(0, max);

// Anything read back from storage becomes a complete, valid letter.
export const normalizeLetter = (saved) => {
  const base = defaultLetter();
  if (!saved || typeof saved !== 'object') return base;
  const edited = saved.bodyEdited === true && typeof saved.body === 'string';
  return {
    jobTitle: text(saved.jobTitle, MAX_FIELD),
    company: text(saved.company, MAX_FIELD),
    companyAddress: text(saved.companyAddress, MAX_FIELD),
    hiringManager: text(saved.hiringManager, MAX_FIELD),
    dateOverride: /^\d{4}-\d{2}-\d{2}$/.test(saved.dateOverride || '') ? saved.dateOverride : '',
    tone: TONE_IDS.includes(saved.tone) ? saved.tone : base.tone,
    body: edited ? text(saved.body, MAX_BODY) : '',
    bodyEdited: edited,
  };
};

export const loadLetter = (key) => {
  try {
    const raw = localStorage.getItem(STORAGE_PREFIX + key);
    return raw ? normalizeLetter(JSON.parse(raw)) : defaultLetter();
  } catch {
    return defaultLetter();
  }
};

export const saveLetter = (key, letter) => {
  try {
    localStorage.setItem(STORAGE_PREFIX + key, JSON.stringify(letter));
  } catch {
    /* Storage can be blocked or full. The letter still works for this visit. */
  }
};

export const MAX_BODY_CHARS = MAX_BODY;
export const MAX_FIELD_CHARS = MAX_FIELD;
export const todayIso = todayISO;
